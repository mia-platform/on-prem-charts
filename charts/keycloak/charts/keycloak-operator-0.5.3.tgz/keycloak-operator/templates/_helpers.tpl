{{/*
Expand the name of the chart.
*/}}
{{- define "keycloak-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name (truncated to 63 chars).
*/}}
{{- define "keycloak-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Operator deployment name (truncated to 54 + "-operator").
*/}}
{{- define "keycloak-operator.operator.fullname" -}}
{{ include "keycloak-operator.fullname" . | trunc 54 | trimSuffix "-" }}-operator
{{- end }}

{{/*
Chart label.
*/}}
{{- define "keycloak-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "keycloak-operator.labels" -}}
helm.sh/chart: {{ include "keycloak-operator.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Operator labels (common + selector).
*/}}
{{- define "keycloak-operator.operator.labels" -}}
{{ include "keycloak-operator.labels" . }}
{{ include "keycloak-operator.operator.selectorLabels" . }}
{{- end }}

{{/*
Operator selector labels.
*/}}
{{- define "keycloak-operator.operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "keycloak-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: keycloak-operator
{{- end }}

{{/*
ServiceAccount name.
*/}}
{{- define "keycloak-operator.operator.serviceAccountName" -}}
{{- if .Values.operator.serviceAccount.create }}
{{- default (include "keycloak-operator.fullname" .) .Values.operator.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.operator.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Check if the Keycloak version supports a feature based on a minimum semver.
Usage: include "keycloak.versionAtLeast" (dict "context" $ "version" "26.6.0")
*/}}
{{- define "keycloak.versionAtLeast" -}}
{{- if semverCompare (printf ">=%s" .version) .context.Values.keycloak.version -}}
true
{{- end -}}
{{- end -}}

{{/*
Resolve a nested field with a fallback default.
Usage: include "keycloak.nestedDefault" (dict "map" .someObject "key" "fieldName" "default" "fallback")
*/}}
{{- define "keycloak.nestedDefault" -}}
{{- if .map -}}
  {{- $val := index .map .key -}}
  {{- if not (kindIs "invalid" $val) -}}
    {{- $val -}}
  {{- else -}}
    {{- .default -}}
  {{- end -}}
{{- else -}}
  {{- .default -}}
{{- end -}}
{{- end -}}

{{/*
Build the kc.user.profile.config JSON object.
Accepts the realm item as context (.). Merges .userProfileConfig.attributes
and .userProfileConfig.groups with the defaults.
*/}}
{{- define "keycloak.userProfileConfig" -}}
{{- $defaultAttrs := list
  (dict "name" "username" "displayName" "${username}" "validations" (dict "length" (dict "min" 3 "max" 255) "username-prohibited-characters" (dict) "up-username-not-idn-homograph" (dict)) "permissions" (dict "view" (list "admin" "user") "edit" (list "admin" "user")) "multivalued" false)
  (dict "name" "email" "displayName" "${email}" "validations" (dict "email" (dict) "length" (dict "max" 255)) "permissions" (dict "view" (list "admin" "user") "edit" (list "admin" "user")) "multivalued" false)
  (dict "name" "firstName" "displayName" "${firstName}" "validations" (dict "length" (dict "max" 255) "person-name-prohibited-characters" (dict)) "permissions" (dict "view" (list "admin" "user") "edit" (list "admin" "user")) "multivalued" false)
  (dict "name" "lastName" "displayName" "${lastName}" "validations" (dict "length" (dict "max" 255) "person-name-prohibited-characters" (dict)) "permissions" (dict "view" (list "admin" "user") "edit" (list "admin" "user")) "multivalued" false)
-}}
{{- $defaultGroups := list
  (dict "name" "user-metadata" "displayHeader" "User metadata" "displayDescription" "Attributes, which refer to user metadata")
-}}
{{- $extraAttrs := list -}}
{{- $extraGroups := list -}}
{{- if .userProfileConfig -}}
  {{- if .userProfileConfig.attributes -}}
    {{- $extraAttrs = .userProfileConfig.attributes -}}
  {{- end -}}
  {{- if .userProfileConfig.groups -}}
    {{- $extraGroups = .userProfileConfig.groups -}}
  {{- end -}}
{{- end -}}
{{- $allAttrs := concat $defaultAttrs $extraAttrs -}}
{{- $allGroups := concat $defaultGroups $extraGroups -}}
{{- $upConfig := dict "attributes" $allAttrs "groups" $allGroups -}}
{{- if .userProfileConfig -}}
  {{- if .userProfileConfig.unmanagedAttributePolicy -}}
    {{- $_ := set $upConfig "unmanagedAttributePolicy" .userProfileConfig.unmanagedAttributePolicy -}}
  {{- end -}}
{{- end -}}
{{- $upConfig | toJson -}}
{{- end -}}
