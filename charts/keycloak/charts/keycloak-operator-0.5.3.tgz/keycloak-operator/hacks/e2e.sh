#!/usr/bin/env bash

set -euo pipefail

###############################################################################
# e2e.sh — End-to-end test lifecycle: setup → test → teardown
#
# The cluster is always torn down on exit, whether tests
# pass or fail. Exit code reflects test outcome.
#
# Expected environment (set by the Makefile):
#   KUBECONFIG          path to the local kubeconfig file
#   KIND_CLUSTER_NAME   name of the Kind cluster
#   POSTGRES_VERSION    PostgreSQL image tag
#   POSTGRES_SHA        (optional) image digest
###############################################################################

: "${KUBECONFIG:?KUBECONFIG must be set}"
: "${KIND_CLUSTER_NAME:?KIND_CLUSTER_NAME must be set}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${SCRIPT_DIR}/.."
TEST_RESULT=0

###############################################################################
# Helpers
###############################################################################

readonly BOLD='\033[1m'
readonly CYAN='\033[36m'
readonly GREEN='\033[32m'
readonly YELLOW='\033[33m'
readonly BLUE='\033[34m'
readonly RED='\033[31m'
readonly RESET='\033[0m'

log_step() {
    echo ""
    echo -e "${CYAN}${BOLD}====================" \
        "====================" \
        "==================${RESET}"
    echo -e "${CYAN}${BOLD}  $1${RESET}"
    echo -e "${CYAN}${BOLD}====================" \
        "====================" \
        "==================${RESET}"
    echo ""
}

log_info() {
    echo -e "${BLUE}[INFO]${RESET}  $1"
}

log_ok() {
    echo -e "${GREEN}[OK]${RESET}    $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${RESET}  $*"
}

log_error() {
    echo -e "${RED}[ERROR]${RESET} $*"
}

###############################################################################
# Teardown — always runs on exit
###############################################################################

teardown() {
    log_step "Teardown"

    if kind get clusters 2>/dev/null \
        | grep -q "^${KIND_CLUSTER_NAME}$"; then
        log_info "Deleting Kind cluster" \
            "'${KIND_CLUSTER_NAME}'..."
        kind delete cluster \
            --name="${KIND_CLUSTER_NAME}" || true
    fi

    rm -f "${KUBECONFIG}"
    rm -f "${SCRIPT_DIR}/.cluster_up.state"
    rm -f "${SCRIPT_DIR}/.postgres_up.state"

    if [[ ${TEST_RESULT} -eq 0 ]]; then
        log_ok "Tests passed. Cluster cleaned up."
    else
        log_error "Tests failed (exit ${TEST_RESULT})." \
            "Cluster cleaned up."
    fi
}

trap teardown EXIT

###############################################################################
# Setup
###############################################################################

log_step "Setup — Creating test environment"

bash "${SCRIPT_DIR}/cluster_up.sh"

log_info "Building and loading Keycloak image..."
make -C "${REPO_ROOT}" build

log_info "Generating TLS certificates..."
make -C "${REPO_ROOT}" certs

bash "${SCRIPT_DIR}/postgres_up.sh"
bash "${SCRIPT_DIR}/keycloak_secrets.sh"

log_info "Deploying chart..."
make -C "${REPO_ROOT}" deploy

###############################################################################
# Wait for Keycloak to be ready
###############################################################################

log_step "Waiting for Keycloak to be ready"

log_info "Waiting for Keycloak pods..."
kubectl wait --namespace keycloak \
    --for=condition=ready pod \
    --selector=app=keycloak \
    --timeout=300s || {
    log_warn "Keycloak pods not ready yet," \
        "checking operator status..."
    kubectl get pods -n keycloak
    kubectl get keycloak -n keycloak -o yaml \
        2>/dev/null || true
}

log_ok "Keycloak is running."

###############################################################################
# Run tests
###############################################################################

log_step "Running e2e tests"

# Add your test commands here. Examples:
#   - curl smoke tests against the Keycloak API
#   - helm test
#   - custom test scripts
#
# Set TEST_RESULT to capture failures so teardown
# still runs but the script exits non-zero.

helm test keycloak --namespace keycloak --timeout 120s \
    || TEST_RESULT=$?

# Placeholder for additional test commands:
# bash "${SCRIPT_DIR}/run_e2e_tests.sh" || TEST_RESULT=$?

if [[ ${TEST_RESULT} -eq 0 ]]; then
    log_ok "All tests passed."
else
    log_error "Some tests failed."
fi

###############################################################################
# Teardown runs via EXIT trap
###############################################################################

exit ${TEST_RESULT}
