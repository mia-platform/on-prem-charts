#!/usr/bin/env bash

set -euo pipefail

###############################################################################
# postflight.sh — Inspect actual Helm release Secret size
#
# Environment:
#   RELEASE         Helm release name
#   NAMESPACE       Kubernetes namespace where release is installed
#   KUBECONFIG      location of kubectl config file
###############################################################################

###############################################################################
# Helpers
###############################################################################

readonly GREEN='\033[32m'
readonly YELLOW='\033[33m'
readonly BLUE='\033[34m'
readonly RED='\033[31m'
readonly RESET='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${RESET}  $1"
}

log_ok() {
    echo -e "${GREEN}[OK]${RESET}    $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${RESET}  $*"
}

log_error() {
    echo -e "${RED}[ERROR]${RESET} $*"
}

###############################################################################
# Preflight — check required binaries and env vars
###############################################################################

REQUIRED_BINS=(helm kubectl jq base64 wc tr)
missing=()

for bin in "${REQUIRED_BINS[@]}"; do
    if ! command -v "${bin}" &> /dev/null; then
        missing+=("${bin}")
    fi
done

if [[ ${#missing[@]} -gt 0 ]]; then
    log_error "Missing required binaries: ${missing[*]}"
    exit 1
fi

if [[ -z "${RELEASE:-}" ]]; then
    log_error "Required env var 'RELEASE'"
    exit 1
fi

if [[ -z "${NAMESPACE:-}" ]]; then
    log_error "Required env var 'NAMESPACE'"
    exit 1
fi

###############################################################################
# Postflight — read latest release Secret and print size metrics
###############################################################################

revision="$(helm history "${RELEASE}" -n "${NAMESPACE}" -o json | jq -r '.[-1].revision')"
if [[ -z "${revision}" || "${revision}" == "null" ]]; then
    log_error "Unable to determine latest Helm revision for ${RELEASE} in namespace ${NAMESPACE}."
    exit 1
fi

secret_name="sh.helm.release.v1.${RELEASE}.v${revision}"

log_info "Inspecting release Secret ${secret_name}"

secret_json_bytes="$(kubectl get secret "${secret_name}" -n "${NAMESPACE}" -o json | wc -c | tr -d ' ')"
secret_json_kib=$(( (secret_json_bytes + 1023) / 1024 ))
release_field_chars="$(kubectl get secret "${secret_name}" -n "${NAMESPACE}" -o jsonpath='{.data.release}' | wc -c | tr -d ' ')"
decoded_release_bytes="$(kubectl get secret "${secret_name}" -n "${NAMESPACE}" -o jsonpath='{.data.release}' | base64 -d | wc -c | tr -d ' ')"
decoded_release_kib=$(( (decoded_release_bytes + 1023) / 1024 ))

status="OK"
if [[ ${secret_json_kib} -ge 900 ]]; then
    status="HIGH"
elif [[ ${secret_json_kib} -ge 700 ]]; then
    status="WARN"
fi

if [[ "${status}" == "HIGH" ]]; then
    log_warn "Release Secret is close to object size limits."
fi

echo "Postflight actual release secret size"
echo "  release:             ${RELEASE}"
echo "  namespace:           ${NAMESPACE}"
echo "  revision:            ${revision}"
echo "  secret:              ${secret_name}"
echo "  secret JSON size:    ${secret_json_bytes} bytes (${secret_json_kib} KiB)"
echo "  data.release chars:  ${release_field_chars}"
echo "  decoded payload:     ${decoded_release_bytes} bytes (${decoded_release_kib} KiB)"
echo "  status:              ${status}"

log_ok "Postflight check complete."