#!/usr/bin/env bash
# update_keycloak.sh — bump Keycloak version across all files
#
# Usage:
#   ./hacks/update_keycloak.sh <NEW_VERSION>
#
# What it does:
#   1. Resolves the image digest from quay.io/keycloak/keycloak:<version>
#   2. Downloads CRDs from keycloak/keycloak-k8s-resources GitHub release
#   3. Updates all version references across the repo:
#      - .docker/Dockerfile        (ARG defaults)
#      - .kind/tools.mk            (KEYCLOAK_VERSION, KEYCLOAK_SHA)
#      - .kind/overrides.yaml      (image tag)
#      - .gitlab-ci.yml            (matrix: TAG_SUFFIX, KEYCLOAK_VERSION, KEYCLOAK_SHA)
#      - values.yaml               (keycloak.version)
#      - crds/                     (CRD YAML files)
#
# Prerequisites: curl, jq, sed, skopeo (for digest lookup)

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

# ── Parse arguments ───────────────────────────────────────

NEW_VERSION=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)
      sed -n '2,/^$/s/^# //p' "$0"
      exit 0
      ;;
    -*)
      echo "Unknown flag: $1" >&2
      exit 1
      ;;
    *)
      NEW_VERSION="$1"
      shift
      ;;
  esac
done

if [[ -z "$NEW_VERSION" ]]; then
  echo "Usage: $0 <NEW_VERSION>" >&2
  exit 1
fi

# ── Read current versions ────────────────────────────────

OLD_VERSION=$(grep -oP '^KEYCLOAK_VERSION\s*:=\s*\K\S+' .kind/tools.mk)
OLD_SHA=$(grep -oP '^KEYCLOAK_SHA\s*:=\s*\K\S+' .kind/tools.mk)

OLD_SUFFIX="${OLD_VERSION}-postgres"
NEW_SUFFIX="${NEW_VERSION}-postgres"

echo "╔══════════════════════════════════════════════════╗"
echo "║       Keycloak Version Update                    ║"
echo "╠══════════════════════════════════════════════════╣"
printf "║  Keycloak : %-12s → %-12s          ║\n" "$OLD_VERSION" "$NEW_VERSION"
printf "║  Suffix   : %-36s ║\n" "$NEW_SUFFIX"
echo "╚══════════════════════════════════════════════════╝"
echo

# ── Step 1: Resolve image digest ─────────────────────────

echo "[1/4] Resolving image digest for quay.io/keycloak/keycloak:${NEW_VERSION}..."

NEW_SHA=""
if command -v skopeo &>/dev/null; then
  NEW_SHA=$(skopeo inspect "docker://quay.io/keycloak/keycloak:${NEW_VERSION}" 2>/dev/null \
    | jq -r '.Digest' 2>/dev/null) || true
fi
if [[ -z "${NEW_SHA:-}" || "$NEW_SHA" == "null" ]] && command -v docker &>/dev/null; then
  NEW_SHA=$(docker manifest inspect "quay.io/keycloak/keycloak:${NEW_VERSION}" 2>/dev/null \
    | jq -r '.manifests[] | select(.platform.architecture == "amd64" and .platform.os == "linux") | .digest' 2>/dev/null) || true
  # If multi-arch manifest, fall back to the single digest
  if [[ -z "$NEW_SHA" || "$NEW_SHA" == "null" ]]; then
    NEW_SHA=$(docker manifest inspect "quay.io/keycloak/keycloak:${NEW_VERSION}" 2>/dev/null \
      | jq -r '.config.digest // .digest' 2>/dev/null) || true
  fi
fi

if [[ -z "${NEW_SHA:-}" || "$NEW_SHA" == "null" ]]; then
  echo "[WARN] Could not resolve digest automatically."
  echo "       This may mean the tag '${NEW_VERSION}' does not exist."
  echo "       You can find it at: https://quay.io/repository/keycloak/keycloak?tab=tags"
  read -rp "       Enter digest (sha256:...) or 'q' to abort: " NEW_SHA
  if [[ -z "$NEW_SHA" || "$NEW_SHA" == "q" ]]; then
    echo "[ABORT] No digest provided. Exiting."
    exit 1
  fi
fi

if [[ ! "$NEW_SHA" =~ ^sha256:[a-f0-9]{64}$ ]]; then
  echo "[ERROR] Invalid digest format: ${NEW_SHA}"
  echo "        Expected: sha256:<64 hex chars>"
  exit 1
fi

echo "       Digest: ${NEW_SHA}"
echo

# ── Step 2: Download CRDs ────────────────────────────────

echo "[2/4] Downloading CRDs from keycloak-k8s-resources ${NEW_VERSION}..."

CRD_BASE="https://raw.githubusercontent.com/keycloak/keycloak-k8s-resources/${NEW_VERSION}/kubernetes"
CRD_DIR="crds"

CRD_FAIL=0
for crd in keycloaks.k8s.keycloak.org-v1.yml keycloakrealmimports.k8s.keycloak.org-v1.yml; do
  echo "       Fetching ${crd}..."
  if ! curl -fsSL "${CRD_BASE}/${crd}" -o "${CRD_DIR}/${crd}"; then
    echo "[WARN] Failed to download ${crd}."
    CRD_FAIL=1
  fi
done

if [[ $CRD_FAIL -eq 1 ]]; then
  echo
  echo "       CRDs may have a different path in this release."
  echo "       Check: https://github.com/keycloak/keycloak-k8s-resources/tree/${NEW_VERSION}/kubernetes"
  read -rp "       Continue anyway? [y/N] " CONTINUE
  if [[ ! "$CONTINUE" =~ ^[Yy]$ ]]; then
    echo "[ABORT] Fix CRDs manually and re-run."
    exit 1
  fi
fi
echo

# ── Step 3: Update version references ────────────────────

echo "[3/4] Updating version references..."

# --- .docker/Dockerfile ---
echo "       .docker/Dockerfile"
sed -i \
  -e "s|^ARG KEYCLOAK_VERSION=.*|ARG KEYCLOAK_VERSION=\"${NEW_VERSION}\"|" \
  -e "s|^ARG KEYCLOAK_SHA=.*|ARG KEYCLOAK_SHA=\"${NEW_SHA}\"|" \
  .docker/Dockerfile

# --- .kind/tools.mk ---
echo "       .kind/tools.mk"
sed -i \
  -e "s|^KEYCLOAK_VERSION := .*|KEYCLOAK_VERSION := ${NEW_VERSION}|" \
  -e "s|^KEYCLOAK_SHA     := .*|KEYCLOAK_SHA     := ${NEW_SHA}|" \
  .kind/tools.mk

# --- values.yaml ---
echo "       values.yaml"
# keycloak.version (image tag is managed independently via values)
sed -i "s|^\(  version: \)${OLD_VERSION}|\1${NEW_VERSION}|" values.yaml

# --- .gitlab-ci.yml (append new matrix target) ---
echo "       .gitlab-ci.yml (new matrix entry)"

# Check if this version already exists in the matrix
if grep -q "KEYCLOAK_VERSION: \"${NEW_VERSION}\"" .gitlab-ci.yml; then
  echo "       [SKIP] Matrix entry for ${NEW_VERSION} already exists"
else
  # Build the new matrix entry block
  NEW_ENTRY="  - TAG_SUFFIX: \"-${NEW_SUFFIX}\"\n    KEYCLOAK_VERSION: \"${NEW_VERSION}\"\n    KEYCLOAK_SHA: \"${NEW_SHA}\""

  # Insert after the last KEYCLOAK_SHA line inside the matrix block
  LAST_SHA_LINE=$(grep -n 'KEYCLOAK_SHA:' .gitlab-ci.yml | tail -1 | cut -d: -f1)
  sed -i "${LAST_SHA_LINE}a\\
\\
${NEW_ENTRY}" .gitlab-ci.yml

  echo "       Added matrix entry for ${NEW_VERSION}"
fi

echo

# ── Step 4: Summary ──────────────────────────────────────

echo "[4/4] Verifying changes..."
echo

# Show all remaining references to OLD version as a sanity check
# (gitlab-ci.yml is excluded because old matrix entries are kept intentionally)
REMAINING=$(grep -rn --include='*.yaml' --include='*.yml' --include='*.mk' \
  --include='Makefile' --include='Dockerfile' \
  "$OLD_VERSION" . 2>/dev/null \
  | grep -v '.helm/' \
  | grep -v '.gitlab-ci.yml' \
  | grep -v 'node_modules/' \
  | grep -v 'charts/' \
  || true)

if [[ -n "$REMAINING" ]]; then
  echo "[WARN] Old version '${OLD_VERSION}' still found in:"
  echo "$REMAINING" | sed 's/^/       /'
  echo
  echo "       Review these manually — some may be intentional (docs, changelogs)."
else
  echo "[OK]   No remaining references to '${OLD_VERSION}' in tracked files."
fi

echo
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Done. Next steps:"
echo "    1. Review changes:  git diff"
echo "    2. Build image:     make build   (or let CI do it)"
echo "    3. Test locally:    make dev"
echo "    4. Commit:          git add -A && git commit -m 'chore(keycloak): bump to ${NEW_VERSION}'"
echo "    5. Tag image:       make docker-tag DOCKER_VERSION=${NEW_VERSION}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
