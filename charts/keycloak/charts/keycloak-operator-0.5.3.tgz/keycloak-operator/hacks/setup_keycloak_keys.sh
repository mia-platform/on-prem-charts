#!/usr/bin/env bash

set -euo pipefail

###############################################################################
# setup_authtool_bff_keys.sh — Extracts credentials from docker host machine
#
# Environment:
#   OUTPUT_DIR                           output directory (default $ROOT/.kind/.local/keycloak/keys)
#   KUBECONFIG                           location of kubectl config file
#   NAMESPACE                            namespace for secrets
#   KEYCLOAK_KEYSTORE_VAULT_SECRET_NAME  keycloak vault secret name (default: keycloak-vault-secret)
#   KEYCLOAK_POSTGRES_CREDENTIALS        postgres credentials (default: keycloak-postgres-credentials)
###############################################################################

###############################################################################
# Helpers
###############################################################################

readonly GREEN='\033[32m'
readonly YELLOW='\033[33m'
readonly BLUE='\033[34m'
readonly RED='\033[31m'
readonly RESET='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${RESET}  $1"
}

log_ok() {
    echo -e "${GREEN}[OK]${RESET}    $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${RESET}  $*"
}

log_error() {
    echo -e "${RED}[ERROR]${RESET} $*"
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${SCRIPT_DIR}/.."
OUTPUT_DIR="${OUTPUT_DIR:=${ROOT_DIR}/.kind/.local/keycloak/keys}"

KEYCLOAK_KEYSTORE_VAULT_SECRET_NAME=${KEYCLOAK_KEYSTORE_VAULT_SECRET_NAME:=keycloak-vault-secret}
KEYCLOAK_POSTGRES_CREDENTIALS=${KEYCLOAK_POSTGRES_CREDENTIALS:=keycloak-postgres-credentials}

errors=()
[[ -z "${OUTPUT_DIR}" ]] && errors+=("OUTPUT_DIR env var is required")

if [[ ${#errors[@]} -gt 0 ]]; then
  echo "" >&2
  for err in "${errors[@]}"; do log_error "${err}" >&2; done
  echo "" >&2
  usage
fi

###############################################################################
# Preflight — check required binaries
###############################################################################

REQUIRED_BINS=(openssl kubectl)
missing=()

for bin in "${REQUIRED_BINS[@]}"; do
    if ! command -v "${bin}" &> /dev/null; then
        missing+=("${bin}")
    fi
done

if [[ ${#missing[@]} -gt 0 ]]; then
    log_error "Missing required" \
        "binaries: ${missing[*]}"
    exit 1
fi

###############################################################################
# Create keys
###############################################################################

mkdir -p ${OUTPUT_DIR}

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | \
  kubectl apply -f -

# vault

kubectl --namespace ${NAMESPACE} \
    delete secret ${KEYCLOAK_KEYSTORE_VAULT_SECRET_NAME} \
    --ignore-not-found=true
kubectl create secret generic ${KEYCLOAK_KEYSTORE_VAULT_SECRET_NAME} \
    --namespace ${NAMESPACE} \
    --dry-run=client -o yaml \
    | kubectl apply -f -

# postgres

kubectl --namespace ${NAMESPACE} \
    delete secret ${KEYCLOAK_POSTGRES_CREDENTIALS} \
    --ignore-not-found=true
kubectl create secret generic ${KEYCLOAK_POSTGRES_CREDENTIALS} \
    --from-literal=username=postgres \
    --from-literal=password=postgres \
    --namespace ${NAMESPACE} \
    --dry-run=client -o yaml \
    | kubectl apply -f -

log_ok "Secret created"
