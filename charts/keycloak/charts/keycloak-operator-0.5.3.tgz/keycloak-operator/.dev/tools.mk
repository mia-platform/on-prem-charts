# ──────────────────────────────────────────────────────────
# Kind dev-environment targets
# ──────────────────────────────────────────────────────────
# Included by the top-level Makefile.
# All paths are relative to the repository root (CURDIR).
# ──────────────────────────────────────────────────────────

DOCKER_COMPOSE_FILE := .dev/docker-compose.yml

.PHONY: dc-up dc-down

dc-up:
	@docker compose --file=$(DOCKER_COMPOSE_FILE) up -d --build

dc-down: ## Delete the Kind cluster
	@docker compose --file=$(DOCKER_COMPOSE_FILE) down -v
