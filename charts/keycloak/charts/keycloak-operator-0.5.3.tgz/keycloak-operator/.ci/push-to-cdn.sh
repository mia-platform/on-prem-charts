#!/usr/bin/env bash
set -euo pipefail

# ───────────────────────────────────────────────────────────────────────────────
# ENVIRONMENT REQUIRED
#   CDN_STORAGE_ACCESS_KEY   Bunny Storage API key
#   BUNNY_STORAGE_ZONE       Storage zone name
#   BUNNY_STORAGE_REGION     Optional region prefix ("", uk, ny, la, sg, se, br, jh)
# ───────────────────────────────────────────────────────────────────────────────

: "${CDN_STORAGE_ACCESS_KEY:?CDN_STORAGE_ACCESS_KEY is required}"
: "${BUNNY_STORAGE_ZONE:=mia-platform}"
: "${BUNNY_STORAGE_REGION:=}"

if [[ "$#" -lt 2 ]]; then
  echo "Usage: $0 <destination-storage-path> <file|dir|glob> [...]"
  echo "Example: $0 assets/app dist/ src/*.js index.html"
  exit 1
fi

BUNNY_DEST_PATH="$1"
shift

BASE_HOST="storage.bunnycdn.com"
if [[ -n "$BUNNY_STORAGE_REGION" ]]; then
  BASE_HOST="${BUNNY_STORAGE_REGION}.${BASE_HOST}"
fi

# URL Encode function (preserves RFC3986)
urlencode() {
  local raw="$1"
  local len=${#raw}
  local i c
  for ((i=0; i<len; i++)); do
    c="${raw:i:1}"
    case "$c" in
      [a-zA-Z0-9.~_-]) printf '%s' "$c" ;;
      *) printf '%%%02X' "'$c" ;;
    esac
  done
}

# Upload a single file
upload_file() {
  local root="$1"
  local file="$2"

  local rel_path="${file#$root/}"

  local file_dir file_name
  file_dir="$(dirname "$rel_path")"
  file_name="$(basename "$rel_path")"

  local storage_path
  if [[ "$file_dir" == "." ]]; then
    storage_path="$BUNNY_DEST_PATH"
  else
    storage_path="${BUNNY_DEST_PATH%/}/$file_dir"
  fi

  storage_path="${storage_path#/}"
  storage_path="${storage_path%/}"

  # encode each folder segment
  local encoded_path=""
  if [[ -n "$storage_path" ]]; then
    IFS='/' read -r -a parts <<< "$storage_path"
    for idx in "${!parts[@]}"; do
      [[ $idx -gt 0 ]] && encoded_path+="/"
      encoded_path+="$(urlencode "${parts[$idx]}")"
    done
  fi

  local encoded_name
  encoded_name="$(urlencode "$file_name")"

  local final_url
  if [[ -n "$encoded_path" ]]; then
    final_url="https://${BASE_HOST}/${BUNNY_STORAGE_ZONE}/${encoded_path}/${encoded_name}"
  else
    final_url="https://${BASE_HOST}/${BUNNY_STORAGE_ZONE}/${encoded_name}"
  fi

  echo "→ Upload: $file → $final_url"

  curl --fail --silent --show-error \
    -X PUT \
    -H "AccessKey: $CDN_STORAGE_ACCESS_KEY" \
    -H "Content-Type: application/octet-stream" \
    --data-binary "@$file" \
    "$final_url"
}

# Main
for arg in "$@"; do
  # If glob didn't expand, ignore
  if [[ ! -e "$arg" ]]; then
    echo "Skipping '$arg' – not found"
    continue
  fi

  if [[ -f "$arg" ]]; then
    root_dir="$(dirname "$arg")"
    [[ "$root_dir" == "." ]] && root_dir="."
    upload_file "$root_dir" "$arg"

  elif [[ -d "$arg" ]]; then
    root_dir="${arg%/}"
    while IFS= read -r file; do
      upload_file "$root_dir" "$file"
    done < <(find "$root_dir" -type f)

  else
    echo "Skipping '$arg' – not file or directory"
  fi
done

echo "Done."

